export const environment = {
  production: false,
  //_url: 'http://103.149.113.100:4049',
  _vasURL: 'https://103.149.113.100:8224/api',
  _url: 'https://csm.augtrans.com:4047'
  // _url: 'http://localhost:7426'
};