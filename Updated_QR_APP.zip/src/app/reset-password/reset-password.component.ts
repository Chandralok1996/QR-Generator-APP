import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { Router } from '@angular/router';
// import { UserService } from '../_service/user.service';
// import { MasterService } from '../_service';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.css']
})
export class ResetPasswordComponent {
  username: any;
  username1:any;
  showPass: boolean = true;
  form: any;

  ngOnInit(): void {
  this.form = new FormGroup({
    user_id: new FormControl('',[(Validators.required)]),
    password: new FormControl('',[(Validators.required)]),
    conpassword: new FormControl('',[(Validators.required)]),
  });
}
get formCtrl() {
  return this.form.controls;
}

resetPassword(){}



}
